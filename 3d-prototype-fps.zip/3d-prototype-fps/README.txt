I am still a beginner-intermediate in game development journey. I would be thankful for any code-review, bugs, etc?
Thank y'all!
